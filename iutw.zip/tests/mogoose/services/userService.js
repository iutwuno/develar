//--------------------------------------------------------------------
// <copyright file="userService.js" company="CEPAN">
//     Copyright (c) CEPAN. All rights reserved.
// </copyright>
// <author>Sol Landa - Leonardo Diaz Longhi - Agustin Cassani</author>
//--------------------------------------------------------------------
/**
 * User service
 */
/**
 * Load module dependencies
 */
var userModel = require('../models/userModel.js');

/**
 * Retrieve all usuarios
 * @param callback
 * @param errback
 */
exports.list = function (callback, errback) {
    userModel.find(function(err, users) {
        if (err) {
            errback(err);
            return;
        }

        callback(users);
    });
};

/**
 * Sign in selected user
 * @param user
 * @param callback
 * @param errback
 */
exports.signin = function (user, callback, errback) {
    userModel.findOne({email: user.email}, function(err, user) {
        if (err) {
            errback(err);
            return;
        }

        if (!user) {
            errback({message: 'email o password incorrecto'});
            return;
        }

        callback(user);
    });
};

/**
 * Sign up a new user
 * @param user
 * @param callback
 * @param errback
 */
exports.signup = function (user, callback, errback) {
    userModel.create(user, function(err, user) {
        if (err) {
            errback(err);
            return;
        }

        callback(user);
    });
};