//--------------------------------------------------------------------
// <copyright file="userModel.js" company="CEPAN">
//     Copyright (c) CEPAN. All rights reserved.
// </copyright>
// <author>Sol Landa - Leonardo Diaz Longhi - Agustin Cassani</author>
//--------------------------------------------------------------------
/**
 * User model
 */
/**
 * Load module dependencies
 */
var mongoose = require('mongoose');
var bcrypt = require('bcrypt-nodejs');
// Define user mongoose schema
var userSchema = new mongoose.Schema({
    email: { type: String, required: true },
    password: { type: String, required: true }
});
// We encrypt the password before the user is saved
userSchema.pre('save', function (next) {
    var user = this;
    // Check if password has been changed
    if (!user.isModified('password')) {
        return next();
    }
    // Generate a salt
    bcrypt.genSalt(10, function (err, salt) {
        if (err) {
            return next(err);
        }
        // Hash the password with the created salt
        bcrypt.hash(user.password, salt, null, function (err, hash) {
            if (err) {
                return next(err);
            }
            // Save new encrypted password
            user.password = hash;
            next();
        });
    });
});
// Remove the password from the retrieved user
userSchema.methods.toJSON = function () {
    var user = this.toObject();
    delete user.password;

    return user;
};
// Compare user passwords
userSchema.methods.comparePasswords = function (password, callback) {
    bcrypt.compare(password, this.password, callback);
};
// Define user mongoose model
var user = mongoose.model('usuario', userSchema, 'usuario');
// Export user model to be re-used
module.exports = user;