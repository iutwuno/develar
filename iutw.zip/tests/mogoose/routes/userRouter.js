//--------------------------------------------------------------------
// <copyright file="userRouter.js" company="CEPAN">
//     Copyright (c) CEPAN. All rights reserved.
// </copyright>
// <author>Sol Landa - Leonardo Diaz Longhi - Agustin Cassani</author>
//--------------------------------------------------------------------
/**
 * User router
 */
/**
 * Load module dependencies
 */
var express = require('express');
var userService = require('../services/userService.js');
var jwt = require('jsonwebtoken');
var settings = require('../config/settings.js');
// Create Express router
var router = express.Router();
/**
 * Retrieve all usuarios
 */
router.get('/', function (req, res) {
    userService.list(function(users) {
        res.status(200).json(users);
    }, function(err) {
        res.status(400).json(err);
    });
});
/**
 * Retrieve selected user
 */
router.post('/isunique', function (req, res) {
    userService.signin(req.body, function(user) {
        res.status(200).json(user);
    }, function(err) {
        res.status(400).json(err);
    });
});
/**
 * Sign in selected user
 */
router.post('/signin', function (req, res) {
    userService.signin(req.body, function(user) {
        user.comparePasswords(req.body.password, function (err, isMatch) {
            if (err) {
                res.status(400).json(err);
            }

            if (!isMatch) {
                res.status(401).json({message:'Email y/o Password incorrecto/s.'});
                return;
            }

            var payload = {
                sub: user._id
            };

            var token = jwt.sign(payload, settings.jwtSecret);

            res.status(200).send({
                user: user.toJSON(),
                token: token
            });
        });
    }, function(err) {
        res.status(400).json(err);
    });
});
/**
 * Sign up a new user
 */
router.post('/signup', function (req, res) {
    userService.signup(req.body, function(user) {
        var payload = {
            sub: user._id
        };

        var token = jwt.sign(payload, settings.jwtSecret);

        res.status(201).send({
            user: user.toJSON(),
            token: token
        });
    }, function(err) {
        res.status(400).json(err);
    });
});
// Export router to be re-used
module.exports = router;