
var refreshButton = document.querySelector('#one');


//EJ1: OBSERVER
var source1 = Rx.Observable.create(observer => {
  // Yield a single value and complete
  var nn = 0;

  $("#one").click(function(){
    nn +=1;
    if(nn<=3){
      observer.onNext(nn);
    }else{
      observer.onCompleted();
    }
  });
  

  // Any cleanup logic might go here
  return () => console.log('EJ1: disposed: CLEANUP' )
});

var subscription1 = source1.subscribe(
  x => console.log('onNext EJ1: ' + x),
  e => console.log('onError:' + e),
  () => console.log('EJ1: onCompleted'));


//subscription.dispose();

//Ejemplo 2

var source2 = Rx.Observable.range(1,5);
  
  $("#one").click(function(){
    console.log('ejemplo2 ')
    var subscription2 = source2.subscribe(
      x => console.log('onNext EJ2 Range: ' + x),
      e => console.log('onError Range:' + e),
      () => console.log('onCompleted Range'));

  });



//Ejemplo 3:


//console.log('Current time: ' + Date.now());

var source3 = Rx.Observable.timer(
  5000, /* 5 seconds */
  5000 /* 1 second */)
   .timestamp();


//var subscription3 = source3.subscribe( x => console.log(x.value + ': ' + x.timestamp));



//Ejemplo 4:

var source4 = Rx.Observable.from(['UNO', 'DOS', 'TRES', 'CUATRO']);

//var subscription4 = source4.subscribe( x => console.log('Observing Array: [' + x + ']'));




//Ejemplo 5:
//var indata = new Set([11,12,11,14]);
//var indata = {length: 3};
var indata = new Map([['k1','1111'],['k1',2],['k1',3]]);

var source5 = Rx.Observable.from(indata);
//var subscription5 = source5.subscribe( x => console.log( x[1]));



// Ejemplo 6: Fibonacci

var fibonacci = function* () {
  var fni = 1;
  var fnj = 1;
  while (1){
    var current = fni;
    fni = fnj;
    fnj = fni + current;
    yield current;
  }
}

// Converts a generator to an observable sequence
var source6 = Rx.Observable.from(fibonacci()).take(5);

// Prints out each item
/*
var subscription6 = source6.subscribe(
  x => console.log('Fibonacci: ['+ x + ']'),
  e => console.log('onError: %s', e),
  () => console.log('onCompleted'));

*/

//Ejemplo 7: Hot observables


//console.log('EJ7: Current time: ' + Date.now());

// Creates a sequence
var source7 = Rx.Observable.interval(1000);

// Convert the sequence into a hot sequence
var hot7 = source7.publish();
//var hot7 = source7;

// No value is pushed to 1st subscription at this point
var subscription71 = hot7.subscribe(
  x => console.log('Obs 1: onNext: [' +  x + ']'),
  e => console.log('Observer 1: onError: %s', e),
  () => console.log('Observer 1: onCompleted'));

//console.log('EJ7: 1st subscription: ' + Date.now());

/***********

// Idle for 3 seconds
setTimeout(() => {

  // Hot is connected to source and starts pushing value to subscribers
  hot7.connect();
  
  console.log('EJ7: NOW CONNECT!!!!: ' + Date.now());

  // Idle for another 3 seconds
  setTimeout(() => {

    console.log('EJ7: 2nd subscription: ' + Date.now());
    var subscription72 = hot7.subscribe(
      x => console.log('Obs 2: onNext: [' +  x + ']'),
      e => console.log('Observer 2: onError:' + e),
      () => console.log('Observer 2: onCompleted'));

    setTimeout(() => {
      console.log('************ DISPOSE ***********');
      subscription71.dispose();
      subscription72.dispose();
    }, 5000);

  }, 3000);
}, 3000);

********/


// EJEMPLO 8
// Suscripción a un UI event (variante jQuery)

//var result8 = document.getElementById('ej8div');
//var sources8 = document.querySelectorAll('div');

var result8 = $('#ej8div');
var sources8 = $('div');


//var source8 = Rx.Observable.fromEvent(document, 'mousemove');
var source8 = Rx.Observable.fromEvent(sources8, 'click');


//var subscription8 = source8.subscribe(e => result8.innerHTML = e.clientX + ', ' + e.clientY);
var subscription8 = source8.subscribe(e => result8.html(e.clientX + ', ' + e.clientY));

//EJE 9
// fromEventPattern

var $tbody = $('#dataTable tbody');

// Subject == Observable
var source9 = Rx.Observable.fromEventPattern(
                     h => {
                       console.log(h instanceof Function);
                       $tbody.on('click', 'tr', h); 
                     },
                     h => { $tbody.off('click', 'tr', h); });

// Observer(s)
var subscription91 = source9.subscribe(e => console.log($( e.target ).text()));
var subscription92 = source9.subscribe(e => alert($( e.target ).text()));



/////////////////////////

var refreshButton = document.querySelector('.refresh');
var closeButton1 = document.querySelector('.close1');
var closeButton2 = document.querySelector('.close2');
var closeButton3 = document.querySelector('.close3');

var refreshClickStream = Rx.Observable.fromEvent(refreshButton, 'click');
var close1ClickStream = Rx.Observable.fromEvent(closeButton1, 'click');
var close2ClickStream = Rx.Observable.fromEvent(closeButton2, 'click');
var close3ClickStream = Rx.Observable.fromEvent(closeButton3, 'click');

var requestStream = refreshClickStream.startWith('startup click')
    .map(function() {
        var randomOffset = Math.floor(Math.random()*500);
        return 'https://api.github.com/users?since=' + randomOffset;
    });

var responseStream = requestStream
    .flatMap(function (requestUrl) {
        return Rx.Observable.fromPromise($.getJSON(requestUrl));
    });

function createSuggestionStream(closeClickStream) {
    return closeClickStream.startWith('startup click')
        .combineLatest(responseStream,             
            function(click, listUsers) {
                return listUsers[Math.floor(Math.random()*listUsers.length)];
            }
        )
        .merge(
            refreshClickStream.map(function(){ 
                return null;
            })
        )
        .startWith(null);
}

var suggestion1Stream = createSuggestionStream(close1ClickStream);
var suggestion2Stream = createSuggestionStream(close2ClickStream);
var suggestion3Stream = createSuggestionStream(close3ClickStream);


// Rendering ---------------------------------------------------
function renderSuggestion(suggestedUser, selector) {
    var suggestionEl = document.querySelector(selector);
    if (suggestedUser === null) {
        suggestionEl.style.visibility = 'hidden';
    } else {
        suggestionEl.style.visibility = 'visible';
        var usernameEl = suggestionEl.querySelector('.username');
        usernameEl.href = suggestedUser.html_url;
        usernameEl.textContent = suggestedUser.login;
        var imgEl = suggestionEl.querySelector('img');
        imgEl.src = "";
        imgEl.src = suggestedUser.avatar_url;
    }
}

suggestion1Stream.subscribe(function (suggestedUser) {
    renderSuggestion(suggestedUser, '.suggestion1');
});

suggestion2Stream.subscribe(function (suggestedUser) {
    renderSuggestion(suggestedUser, '.suggestion2');
});

suggestion3Stream.subscribe(function (suggestedUser) {
    renderSuggestion(suggestedUser, '.suggestion3');
});


/***************/

/*****
* UNO: Ejemplo jQuery
*****/

var $div = $('#htitle');
$div.mouseover(()=>{
  $div.html('Estás siguiendo a...')
});

$('#demo').click(()=>{
  console.log('Bravo!');
});



var requestURL = 'https://api.github.com/users';
console.log("UNO: " + Date.now());

$.getJSON(requestURL)
    .done(function(response) { 

          console.log("TRE: " + Date.now());
          console.log(response[2]);
  
      })
    .fail(function(jqXHR, status, error) { 
        console.log('jQuery Error')
      });

console.log("DOS: " + Date.now());



/*********************
* WRAPPING JQUERY: map is not the proper way!!!
*/
var requestStream = Rx.Observable.just('https://api.github.com/users');

var responseStream = requestStream.map(targetUrl =>{
  return Rx.Observable.fromPromise($.getJSON(targetUrl));
  
  })
var subscripcion = responseStream.subscribe((obs)=>{
  obs.subscribe(response => {
    console.log('***** Stream from Promise ****');
    console.log(response.length);
  
  });
  
})

/*****
* Ejemplo jQuery
*****/


/*********************
* WRAPPING JQUERY: map is not the proper way!!!
*/


var $div = $('#htitle');
$div.mouseover(()=>{
  $div.html('Estás siguiendo a...')
});

$('#demo').click(()=>{
  console.log('Bravo!');
});



var requestURL = 'https://api.github.com/users';

console.log("UNO: " + Date.now());
$.getJSON(requestURL)
    .done(function(response) { 

          console.log('***** jQuery Async ****');
          console.log("TRE: " + Date.now());
          console.log('Resp is an Array?: ' + (response instanceof Array));
  
      })
    .fail(function(jqXHR, status, error) { 
        console.log('jQuery Error')
      });

console.log("DOS: " + Date.now());


console.log("ALFA: " + Date.now());
var promise = $.getJSON(requestURL);

promise.then((response)=>{
    console.log('BETA ***** jQuery Promise ****');
    console.log("BETA: " + Date.now());
    console.log('Response length: ' + response.length);
});



/*********************
* WRAPPING JQUERY
*/
var requestStream = Rx.Observable.just('https://api.github.com/users');

var responseStream = requestStream.flatMap(targetUrl =>{
  return Rx.Observable.fromPromise($.getJSON(targetUrl));
  
  });

var subscripcion = responseStream.subscribe( response =>{
    console.log('***** Stream from Promise ****');
    console.log('Response length: ' + response.length);
});





