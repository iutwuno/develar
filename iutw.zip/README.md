# networking
## Gestión colectiva y colaborativa de proyectos.
Prueba de concepto de las líneas de trabajo en desarrollo
