import Marionette from "backbone.marionette";
import template from "../templates/landing.jst";

export default Marionette.View.extend({
	template: template,
	regions: {
	}
});
